#Input types

* text
* email
* password
* date
* checkbox

#Other Form Tags

* Select
* Button
* Fieldset
* div